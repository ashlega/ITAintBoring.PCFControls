var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./TreeRelationships/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./TreeRelationships/index.ts":
/*!************************************!*\
  !*** ./TreeRelationships/index.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n/*\r\n/// <reference types=\"@types/[jstree]\" />\r\n*/\n\nvar jsTreeNodeState =\n/** @class */\nfunction () {\n  function jsTreeNodeState() {}\n\n  return jsTreeNodeState;\n}();\n\nvar jsTreeNode =\n/** @class */\nfunction () {\n  function jsTreeNode() {}\n\n  return jsTreeNode;\n}();\n\nvar TreeRelationships =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function TreeRelationships() {\n    this.selectedItems = [];\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  TreeRelationships.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this.container = container;\n    this.contextObj = context; // Need to track container resize so that control could get the available width. The available height won't be provided even this is true\n\n    context.mode.trackContainerResize(true); // Create main table container div. \n\n    this.mainContainer = document.createElement(\"div\");\n    this.controlId = \"foo\";\n    this.mainContainer.innerHTML = \"\\n\\t\\t    <div id=\\\"\" + this.controlId + \"\\\" class=\\\"jstree-open\\\">\\n\\t\\t\\t  <ul>\\n\\t\\t\\t\\t\\n\\t\\t\\t  </ul>\\n\\t\\t\\t</div>\\n\\t\\t\";\n    /*\r\n    \r\n    <li>Root node 1\r\n              <ul>\r\n                <li>Child node 1</li>\r\n                <li><a href=\"#\">Child node 2</a></li>\r\n              </ul>\r\n            </li>\r\n    \r\n    var jsTreeCSS = document.createElement('link ');\r\n    jsTreeCSS.setAttribute(\"rel\",\"stylesheet\");\r\n    jsTreeCSS.setAttribute(\"href\", \"https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/themes/default/style.min.css\");\r\n    */\n\n    this._initTreeHandler = this.initTree.bind(this);\n    var scriptElement = document.createElement(\"script\");\n    scriptElement.src = \"https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/jstree.min.js\";\n    scriptElement.type = \"text/javascript\";\n    container.appendChild(scriptElement);\n    container.appendChild(this.mainContainer); //this.mainContainer.innerHTML += \"<script>setTimeout(function(){ $(\" + controlId + \").jstree(); }, 1000);</script>\"\n\n    /*\r\n    var jsTreeScript = document.createElement('script');\r\n    jsTreeScript.setAttribute(\"type\",\"text/javascript\");\r\n    jsTreeScript.setAttribute(\"src\", \"https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/jstree.min.js\");\r\n    \r\n    container.appendChild(jsTreeScript);\r\n    this.initTree('#foo');\r\n    */\n\n    var scriptElementOnLoad = document.createElement(\"script\");\n    scriptElementOnLoad.type = \"text/javascript\";\n    scriptElementOnLoad.innerHTML = \"\\n\\t\\t     \\n\\t\\t\\t\\n\\t\\t    initTreeControl();\\n\\t\\t\\t\\n\\t\\t\\tfunction initTreeControl()\\n\\t\\t\\t{\\n\\t\\t\\t\\tif(typeof($('#\" + this.controlId + \"').jstree) == 'undefined')\\n\\t\\t\\t\\t{\\n\\t\\t\\t\\t\\tsetTimeout(initTreeControl, 500);\\n\\t\\t\\t\\t}\\n\\t\\t\\t\\telse\\n\\t\\t\\t\\t{\\n\\t\\t\\t\\t\\twindow.top.\" + this.controlId + \"= $('#\" + this.controlId + \"');\\n\\t\\t\\t\\t\\t\\n\\t\\t\\t\\t}\\n\\t\\t\\t}\\n\\t\\t\\t \\n\\t\\t\";\n    /*//$('#`+ this.controlId +`').jstree();*/\n\n    this.container.appendChild(scriptElementOnLoad);\n    if (context.parameters.treeEntityName != null) this._treeEntityName = context.parameters.treeEntityName.raw;\n    if (context.parameters.treeEntityAttribute != null) this._treeEntityAttribute = '_' + context.parameters.treeEntityAttribute.raw + '_value';\n    if (context.parameters.idAttribute != null) this._idAttribute = context.parameters.idAttribute.raw;\n    if (context.parameters.nameAttribute != null) this._nameAttribute = context.parameters.nameAttribute.raw;\n    if (context.parameters.relationshipEntity != null) this._relationshipEntity = context.parameters.relationshipEntity.raw;\n    if (context.parameters.relationshipName != null) this._relationshipName = context.parameters.relationshipName.raw;\n    this._relationshipSuccessCallback = this.relationshipSuccessCallback.bind(this);\n    this._successCallback = this.successCallback.bind(this);\n    this.root = new jsTreeNode();\n    this.root.id = null;\n    this.root.children = [];\n    this._onNodeCheckClick = this.nodeClick.bind(this);\n    this._entityMetadataSuccessCallback = this.entityMetadataSuccessCallback.bind(this);\n    this._treeMetadataSuccessCallback = this.treeMetadataSuccessCallback.bind(this);\n    Xrm.Utility.getEntityMetadata(this.contextObj.page.entityTypeName, []).then(this._entityMetadataSuccessCallback, this.errorCallback);\n    Xrm.Utility.getEntityMetadata(this._treeEntityName, []).then(this._treeMetadataSuccessCallback, this.errorCallback);\n    this.contextObj.webAPI.retrieveMultipleRecords(this._relationshipEntity, \"?$filter=\" + this.contextObj.page.entityTypeName + \"id eq \" + this.contextObj.page.entityId, 5000).then(this._relationshipSuccessCallback, this.errorCallback);\n  };\n\n  TreeRelationships.prototype.entityMetadataSuccessCallback = function (value) {\n    this._mainEntityCollectionName = value.EntitySetName;\n  };\n\n  TreeRelationships.prototype.treeMetadataSuccessCallback = function (value) {\n    this._treeEntityCollectionName = value.EntitySetName;\n  };\n\n  TreeRelationships.prototype.addChildElements = function (value, root) {\n    for (var i in value.entities) {\n      var current = value.entities[i];\n\n      if (current != null && root != null) {\n        if (current[this._treeEntityAttribute] == root.id) {\n          var newNode = new jsTreeNode();\n          newNode.id = current[this._idAttribute];\n          newNode.text = current[this._nameAttribute];\n          newNode.children = [];\n          var checked = this.selectedItems.indexOf(newNode.id) > -1;\n          newNode.state = new jsTreeNodeState();\n          newNode.state.disabled = false;\n          newNode.state.opened = false;\n          newNode.state.selected = checked;\n          root.children.push(newNode);\n          this.addChildElements(value, newNode);\n        }\n      }\n    }\n  };\n\n  TreeRelationships.prototype.successCallback = function (value) {\n    this.addChildElements(value, this.root);\n    this.initTree();\n  };\n\n  TreeRelationships.prototype.relationshipSuccessCallback = function (value) {\n    for (var i in value.entities) {\n      this.selectedItems.push(value.entities[i][this._idAttribute]);\n    }\n\n    this.contextObj.webAPI.retrieveMultipleRecords(this._treeEntityName, \"?$orderby=\" + this._nameAttribute + \" asc\", 5000).then(this._successCallback, this.errorCallback);\n  };\n\n  TreeRelationships.prototype.errorCallback = function (value) {\n    alert(value);\n  };\n\n  TreeRelationships.prototype.initTree = function () {\n    if (window.top[this.controlId].jstree == null) {\n      setTimeout(this._initTreeHandler, 500);\n    } else {\n      window.top[this.controlId].jstree({\n        \"plugins\": [\"checkbox\"],\n        \"core\": {\n          \"data\": this.root.children\n        }\n      });\n\n      var _self = this;\n\n      window.top[this.controlId].bind(\"changed.jstree\", function (e, data) {\n        setTimeout(function () {\n          _self._onNodeCheckClick(data);\n        }, 50);\n      });\n    }\n    /*\r\n    \r\n    debugger;\r\n    var _self = this;\r\n    var current = window;\r\n    while(current != null && current != current.parent)\r\n    {\r\n        var control = (<any>current).$(controlId);\r\n        if(control.jstree != null){\r\n          control.jstree();\r\n          return;\r\n        }\r\n        current = current.parent;\r\n    }\r\n    setTimeout(function(){ _self._initTreeHandler(controlId); }, 500);\r\n    */\n\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  TreeRelationships.prototype.updateView = function (context) {// Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  TreeRelationships.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  TreeRelationships.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  TreeRelationships.prototype.nodeClick = function (data) {\n    /*\r\n    function (e: any, data: any) {\r\n                ProcessClick(\r\n                alert(\"Checked: \" + data.node.id);\r\n                alert(\"Parent: \" + data.node.parent);\r\n                //alert(JSON.stringify(data));\r\n            }\r\n    */\n    var url = Xrm.Utility.getGlobalContext().getClientUrl();\n    var recordUrl = url + \"/api/data/v9.1/\" + this._mainEntityCollectionName + \"(\" + this.contextObj.page.entityId + \")\";\n\n    if (data.action == \"select_node\") {\n      //See himbap samples here: http://himbap.com/blog/?p=2063\n      var associate = {\n        \"@odata.id\": recordUrl\n      };\n      var req = new XMLHttpRequest();\n      req.open(\"POST\", url + \"/api/data/v9.1/\" + this._treeEntityCollectionName + \"(\" + data.node.id + \")/\" + this._relationshipName + \"/$ref\", true);\n      req.setRequestHeader(\"Accept\", \"application/json\");\n      req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n      req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n      req.setRequestHeader(\"OData-Version\", \"4.0\");\n\n      req.onreadystatechange = function () {\n        if (this.readyState == 4\n        /* complete */\n        ) {\n            req.onreadystatechange = null;\n\n            if (this.status == 204) {//alert('Record Associated');\n            } else {\n              var error = JSON.parse(this.response).error;\n              alert(error.message);\n            }\n          }\n      };\n\n      req.send(JSON.stringify(associate));\n    } else if (data.action == \"deselect_node\") {\n      var req = new XMLHttpRequest();\n      req.open(\"DELETE\", url + \"/api/data/v9.1/\" + this._treeEntityCollectionName + \"(\" + data.node.id + \")/\" + this._relationshipName + \"/$ref\" + \"?$id=\" + recordUrl, true);\n      req.setRequestHeader(\"Accept\", \"application/json\");\n      req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n      req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n      req.setRequestHeader(\"OData-Version\", \"4.0\");\n\n      req.onreadystatechange = function () {\n        if (this.readyState == 4\n        /* complete */\n        ) {\n            req.onreadystatechange = null;\n\n            if (this.status == 204) {//alert('Record Disassociated');\n            } else {\n              var error = JSON.parse(this.response).error;\n              alert(error.message);\n            }\n          }\n      };\n\n      req.send();\n    }\n  };\n\n  return TreeRelationships;\n}();\n\nexports.TreeRelationships = TreeRelationships;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TreeRelationships/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ItAintBoring.PCFControls.TreeRelationships', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TreeRelationships);
} else {
	var ItAintBoring = ItAintBoring || {};
	ItAintBoring.PCFControls = ItAintBoring.PCFControls || {};
	ItAintBoring.PCFControls.TreeRelationships = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TreeRelationships;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}