var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./ValueFormatter/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./ValueFormatter/index.ts":
/*!*********************************!*\
  !*** ./ValueFormatter/index.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar ValueFormatter =\n/** @class */\nfunction () {\n  function ValueFormatter() {\n    // RegEx to test against\n    this._characterCase = null;\n  }\n\n  ValueFormatter.prototype.applyFormat = function () {\n    var newValue = this._value;\n\n    if (this._characterCase == \"uppercase\") {\n      newValue = this._value.toUpperCase();\n    } else if (this._characterCase == \"lowercase\") {\n      newValue = this._value.toLowerCase();\n    }\n\n    if (newValue != this._value) {\n      this._value = newValue;\n\n      this._notifyOutputChanged();\n    }\n  };\n\n  ValueFormatter.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    container.style.display = 'none';\n    this._notifyOutputChanged = notifyOutputChanged;\n    if (context.parameters.value != null) this._value = context.parameters.value.raw;\n    if (context.parameters.characterCase != null) this._characterCase = context.parameters.characterCase.raw;\n    this.applyFormat();\n  };\n\n  ValueFormatter.prototype.updateView = function (context) {\n    // storing the latest context from the control.\n    if (context.parameters.value != null) this._value = context.parameters.value.raw;\n    if (context.parameters.characterCase != null) this._characterCase = context.parameters.characterCase.raw;\n    this._context = context;\n    this.applyFormat();\n  };\n\n  ValueFormatter.prototype.getOutputs = function () {\n    return {\n      value: this._value\n    };\n  };\n\n  ValueFormatter.prototype.destroy = function () {};\n\n  return ValueFormatter;\n}();\n\nexports.ValueFormatter = ValueFormatter;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ValueFormatter/index.ts?");

/***/ })

/******/ });
var ItAintBoring = ItAintBoring || {};
ItAintBoring.PCFControls = ItAintBoring.PCFControls || {};
ItAintBoring.PCFControls.ValueFormatter = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ValueFormatter;
pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;